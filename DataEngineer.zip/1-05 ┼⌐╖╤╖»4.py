# Yes24.com의 한국소설을 긁어오는 크롤러를 만들고 싶어요. (밥먹고나서)
# 전체 페이지 가져오기
import bs4
import requests
def  get_product_info(info) :
    names = info.find("div", {"class":"goods_name"})
    name = names.findAll("a")[0].text
    link = names.findAll("a")[0]['href'] # 링크 추출
    price = info.find("em", {"class": "yes_b"}).text  # 각 상품 가격
    link = "http://yes24.com" + link
    return {"name" : name, "link" : link, "price" : price}

def get_page_products(url) :
    html = requests.get(url)
    bs_obj = bs4.BeautifulSoup(html.content, "html.parser")
    ul = bs_obj.find("ul", {"class": "clearfix"})
    infos = ul.findAll("div", {"class": "goods_info"})  # 각 상품 정보 리스트
    prod_info_list = [ get_product_info(info) for info in infos]
    return prod_info_list


baseurl = "http://www.yes24.com/24/Category/Display/001001046001?PageNumber="
pnum = 1

while True :
    try :
        url = baseurl + str(pnum)
        pnum += 1
        page_products = get_page_products(url)
        for page_product in page_products :
            print(page_product['name'] + ',' + page_product['price'] + ',' + page_product['link'])
    except :
        print('끝~~~~')
        break
