# 엑셀 처리 1
import xlrd
inFile = "data/EXCEL/sales_2013.xlsx"
workbook = xlrd.open_workbook(inFile)
sheetCount = workbook.nsheets
print('시트 수 -->', sheetCount)

for  worksheet in  workbook.sheets() :
    sheetName = worksheet.name
    sRow = worksheet.nrows
    sCol = worksheet.ncols
    print(sheetName, sRow, sCol)