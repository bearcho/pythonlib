# Yes24.com의 한국소설을 긁어오는 크롤러를 만들고 싶어요. (밥먹고나서)
#
import bs4
import requests
def  get_product_info(info) :
    names = info.find("div", {"class":"goods_name"})
    name = names.findAll("a")[0].text
    link = names.findAll("a")[0]['href'] # 링크 추출
    price = info.find("em", {"class": "yes_b"}).text  # 각 상품 가격
    link = "http://yes24.com" + link
    return {"name" : name, "link" : link, "price" : price}

url = "http://www.yes24.com/24/Category/Display/001001046001"
html = requests.get(url)
bs_obj =  bs4.BeautifulSoup(html.content, "html.parser")

ul = bs_obj.find("ul", {"class":"clearfix"})
infos = ul.findAll("div", {"class":"goods_info"}) # 각 상품 정보 리스트

for info in infos :
    prod_info = get_product_info(info)
    print(prod_info)

