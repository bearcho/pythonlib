from tkinter import *
from tkinter.filedialog import *
from tkinter.simpledialog import *
from tkinter.messagebox import *
import math
import numpy as np

### 메모리를 확보해서 반환하는 함수
def alloc2DMemory(height, width):
    retMemory = [];
    tmpList = []
    for i in range(height):  # 출력메모리 확보(0으로 초기화)
        tmpList = []
        for k in range(width):
            tmpList.append(0)
        retMemory.append(tmpList)
    return retMemory


def loadImage(fname):
    global window, canvas, paper, filename, inImage, outImage, inW, inH, outW, outH
    fsize = os.path.getsize(fname)  # 파일 크기 확인
    inH = inW = int(math.sqrt(fsize))  # 입력메모리 크기 결정! (중요)
    inImage = [];
    tmpList = []
    # 메모리 할당
    inImage = None
    inImage = alloc2DMemory(inH, inW)

    print(len(inImage))

    # 파일 --> 메모리로 데이터 로딩
    fp = open(fname, 'rb')  # 파일 열기(바이너리 모드)
    for i in range(inH):
        for k in range(inW):
            inImage[i][k] = int(ord(fp.read(1)))
    fp.close()


def openFile():
    global window, canvas, paper, filename, inImage, outImage, inW, inH, outW, outH
    filename = askopenfilename(parent=window,
                               filetypes=(("RAW파일", "*.raw"), ("모든파일", "*.*")))
    loadImage(filename)  # 파일 --> 입력메모리
    equal()  # 입력메모리--> 출력메모리


def display():
    global window, canvas, paper, filename, inImage, outImage, inW, inH, outW, outH, VIEW_X, VIEW_Y
    # 기존에 캐버스 있으면 뜯어내기.
    if canvas != None:
        canvas.destroy()
    # 화면 준비 (고정됨)
    VIEW_X, VIEW_Y = 512, 512
    if VIEW_X >= outW or VIEW_Y >= outH:  # 영상이 512미만이면
        VIEW_X = outW
        VIEW_Y = outH
        step = 1  # 건너뛸숫자
    else:
        step = outW / VIEW_X  # step을 실수도 인정. 128, 256, 512 단위가 아닌 것 고려.

    window.geometry(str(int(VIEW_X * 1.2)) + 'x' + str(int(VIEW_Y * 1.2)))
    canvas = Canvas(window, width=VIEW_X, height=VIEW_Y)
    paper = PhotoImage(width=VIEW_X, height=VIEW_Y)
    canvas.create_image((VIEW_X / 2, VIEW_X / 2), image=paper, state='normal')

    # 화면에 출력. 실수 step을 위해서 numpy 사용
    rgbString = ''  # 여기에 전체 픽셀 문자열을 저장할 계획
    for i in np.arange(0, outH, step):
        tmpString = ''
        for k in np.arange(0, outW, step):
            i = int(i);
            k = int(k)  # 첨자이므로 정수화
            r = g = b = outImage[i][k];
            tmpString += ' #%02x%02x%02x' % (r, g, b)
        rgbString += '{' + tmpString + '} '
    paper.put(rgbString)

    canvas.pack(expand=1, anchor=CENTER)
    status.configure(text='이미지 정보:' + str(outW) + 'x' + str(outH))


def equal():
    global window, canvas, paper, filename, inImage, outImage, inW, inH, outW, outH, VIEW_X, VIEW_Y
    outW = inW;
    outH = inH;
    outImage = None;
    outImage = alloc2DMemory(outH, outW)
    ## 데이터 처리
    for i in range(inH):
        for k in range(inW):
            outImage[i][k] = inImage[i][k]
    display()

def addImage():
    global window, canvas, paper, filename, inImage, outImage, inW, inH, outW, outH, VIEW_X, VIEW_Y
    outW = inW;
    outH = inH;
    outImage = None;
    outImage = alloc2DMemory(outH, outW)
    ## 데이터 처리
    value = askinteger("값입력", "입력될 값-->", minvalue=1, maxvalue=255)
    for i in range(inH):
        for k in range(inW):
            if inImage[i][k] + value > 255 :
                outImage[i][k] = 255
            else :
                outImage[i][k] = inImage[i][k] + value
    display()
def reverseImage():
    global window, canvas, paper, filename, inImage, outImage, inW, inH, outW, outH, VIEW_X, VIEW_Y
    outW = inW;
    outH = inH;
    outImage = None;
    outImage = alloc2DMemory(outH, outW)
    ## 데이터 처리
    for i in range(inH):
        for k in range(inW):
            outImage[i][k] = 255-inImage[i][k]
    display()

def bwImage():
    global window, canvas, paper, filename, inImage, outImage, inW, inH, outW, outH, VIEW_X, VIEW_Y
    outW = inW;
    outH = inH;
    outImage = None;
    outImage = alloc2DMemory(outH, outW)
    ## 데이터 처리
    for i in range(inH):
        for k in range(inW):
            if inImage[i][k] > 127 :
                outImage[i][k] = 255
            else :
                outImage[i][k] = 0
    display()

def mirrorImage():
    global window, canvas, paper, filename, inImage, outImage, inW, inH, outW, outH, VIEW_X, VIEW_Y
    outW = inW;
    outH = inH;
    outImage = None;
    outImage = alloc2DMemory(outH, outW)
    ## 데이터 처리
    for i in range(inH):
        for k in range(inW):
            outImage[i][k] = inImage[i][inW-k-1]
    display()


def zoomOut():
    global window, canvas, paper, filename, inImage, outImage, inW, inH, outW, outH, VIEW_X, VIEW_Y
    scale = askinteger("값입력", "축소될 값-->", minvalue=2, maxvalue=16)
    outW = inW // scale;
    outH = inH // scale;
    outImage = None;
    outImage = alloc2DMemory(outH, outW)
    ## 데이터 처리
    for i in range(inH):
        for k in range(inW):
            outImage[i//scale][k//scale] = inImage[i][k]
    display()

def zoomIn():
    global window, canvas, paper, filename, inImage, outImage, inW, inH, outW, outH, VIEW_X, VIEW_Y
    scale = askinteger("값입력", "확대될 값-->", minvalue=2, maxvalue=16)
    outW = inW * scale;
    outH = inH * scale;
    outImage = None;
    outImage = alloc2DMemory(outH, outW)
    ## 데이터 처리
    for i in range(outH):
        for k in range(outW):
            outImage[i][k] = inImage[i//scale][k//scale]
    display()

import csv
def csvSave() :
    global window, canvas, paper, filename, inImage, outImage, inW, inH, outW, outH, VIEW_X, VIEW_Y
    csvName = filename[:-3] + "csv"
    with open(csvName, 'w', newline='') as fw :
        fw = csv.writer(fw, delimiter=',')
        header_list = ['행','열', '값']
        # 작업 했음.
        fw.writerow(header_list)
        for i in range(outH):
            for k in range(outW):
                fw.writerow( [i,k,outImage[i][k]])
    print(csvName + "으로 저장됨. ㅋㅋㅋㅋㅋ")

from xlwt import  Workbook
import os.path
def excelSave() :
    global window, canvas, paper, filename, inImage, outImage, inW, inH, outW, outH, VIEW_X, VIEW_Y
    excelName = filename[:-3] + "xls"
    outWorkbook = Workbook()  # 저장할 워크북
    outWorksheet = outWorkbook.add_sheet(os.path.basename(excelName)[:-4])
    for  row  in range(outH) :
        for col in range(outW) :
            outWorksheet.write(row, col, outImage[row][col])

    outWorkbook.save(excelName)
    print(excelName + "으로 저장됨. ㅋㅋㅋㅋㅋ")

import xlsxwriter
def excelSave2() :
    global window, canvas, paper, filename, inImage, outImage, inW, inH, outW, outH, VIEW_X, VIEW_Y
    excelName = filename[:-3] + "xls"
    outWorkbook = xlsxwriter.Workbook(excelName)  # 저장할 워크북
    outWorksheet = outWorkbook.add_worksheet(os.path.basename(excelName)[:-4])
    # 열 너비 지정
    outWorksheet.set_column(0, outW, 1.0) # 0.34 크기 정도.
    # 행 높이 지정
    for row in range(outH):
        outWorksheet.set_row(row, 9.5) # 0.35 정도
    for  row  in range(outH) :
        for col in range(outW) :
            data = outImage[row][col]
            if data <= 15 :
                 hexStr = '#' + ('0' + hex(data)[2:]) * 3
            else :
                hexStr = '#' + (hex(data)[2:]) * 3
            cell_format = outWorkbook.add_format()
            cell_format.set_bg_color(hexStr)
            outWorksheet.write(row,col, '', cell_format)
    outWorkbook.close()
    print(excelName + "으로 저장됨. ㅋㅋㅋㅋㅋ")

def loadCSV(fname):
    global window, canvas, paper, filename, inImage, outImage, inW, inH, outW, outH
    # 행 개수 알아내기
    csvFP = open(fname, 'r')
    fr = csv.reader(csvFP, delimiter=',')
    header = next(fr)
    numLine = sum(1 for line in fr)
    inH = inW = int(math.sqrt(numLine))  # 입력메모리 크기 결정! (중요)
    inImage = [];    tmpList = []
    # 메모리 할당
    inImage = None;    inImage = alloc2DMemory(inH, inW);    print(len(inImage))
    # 파일 --> 메모리로 데이터 로딩
    csvFP.seek(0,0)
    header = next(fr)
    for rows in  fr :
        row, col, value = list(map(int,rows))
        inImage[row][col] = value
    csvFP.close()

def csvOpen():
    global window, canvas, paper, filename, inImage, outImage, inW, inH, outW, outH
    filename = askopenfilename(parent=window,
                               filetypes=(("CSV파일", "*.csv"), ("모든파일", "*.*")))
    loadCSV(filename)  # 파일 --> 입력메모리
    equal()  # 입력메모리--> 출력메모리
## 전역변수 선언부
window, canvas = [None] * 2

## 메인코드부
if __name__ == "__main__":
    window = Tk();
    window.title('CJ 데이터 분석')
    canvas = Canvas(window, height=256, width=256)
    status = Label(window, text='이미지 정보:', bd=1, relief=SUNKEN, anchor=W)
    status.pack(side=BOTTOM, fill=X)

    mainMenu = Menu(window);
    window.config(menu=mainMenu)
    fileMenu = Menu(mainMenu);
    mainMenu.add_cascade(label='파일', menu=fileMenu)
    fileMenu.add_command(label='열기', command=openFile)

    photoMenu = Menu(mainMenu);
    mainMenu.add_cascade(label='영상처리', menu=photoMenu)
    photoMenu.add_command(label='밝게하기', command=addImage)
    photoMenu.add_command(label='반전하기', command=reverseImage)
    photoMenu.add_command(label='완전흑백', command=bwImage)
    photoMenu.add_command(label='좌우위치', command=mirrorImage)
    photoMenu.add_command(label='축소하기', command=zoomOut)
    photoMenu.add_command(label='확대하기', command=zoomIn)

    dataMenu = Menu(mainMenu);
    mainMenu.add_cascade(label='데이터분석', menu=dataMenu)
    dataMenu.add_command(label='CSV 저장', command=csvSave)
    dataMenu.add_command(label='CSV 열기', command=csvOpen)
    dataMenu.add_command(label='엑셀 저장', command=excelSave)
    dataMenu.add_command(label='엑셀 저장(그림)', command=excelSave2)

    canvas.pack()
    window.mainloop()




