from sklearn import svm, metrics
from sklearn.model_selection import train_test_split
import numpy as np
import pandas as pd

## 1. 머신러닝 알고리즘을 선택 (Classifire 생성)
clf = svm.LinearSVC()

## 2. 데이터 준비하기 (Pandas 응용)
csv = pd.read_csv('data/iris.csv')
data = csv.iloc[:, 0:-1]
label = csv.iloc[:, [-1]]
## 훈련용, 테스트용 분리
train_data, test_data, train_label, test_label = \
    train_test_split(data, label)
## 3. 훈련용 데이터로 학습시키기
clf.fit(train_data, train_label.values.ravel())

## 4. 정답률(신뢰도) 구하기.
result = clf.predict(test_data)
score = metrics.accuracy_score(result, test_label)
print('정답률 :', "{0:.2f}%".format(score*100))

## 5. 길가의 꽃을 꺽어서 예측해 보기
flower = [4.1, 3.3, 1.5, 0.2] # 스마트폰으로 찍어서 자동 계산됨.
result = clf.predict([flower])
print(result)