# CSV 처리 2
import csv
inFile = 'data/csv/supplier_data.csv'
outFile = 'data/output/out02.csv'

with open(inFile, 'r', newline='') as fr :
    with open(outFile, 'w', newline='') as fw :
        fr = csv.reader(fr, delimiter=',')
        fw = csv.writer(fw, delimiter=',')
        header_list = next(fr) # 리스트로 처리됨
        # 작업 했음.
        fw.writerow(header_list)
        for row_list in fr :
            # row_list로 작업하기
            fw.writerow(row_list)
print('Ok~')







# fr.close()
# fw.close()