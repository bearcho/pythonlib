
print("hello~ Python~")
