from tkinter import *
## 함수 부분

## 전역 변수 부분
window, canvas, paper = None, None, None
XSIZE, YSIZE = 512, 512

## 메인 코드 부분
window = Tk()
canvas = Canvas(window, height=XSIZE, width=YSIZE)
paper = PhotoImage(height=XSIZE, width=YSIZE)
canvas.create_image( (XSIZE/2, YSIZE/2), image=paper, state='normal')




canvas.pack()
window.mainloop()


