# CSV 처리 1
inFile = 'data/csv/supplier_data.csv'
outFile = 'data/output/out01.csv'

# fr = open(inFile, 'r', newline='')
# fw = open(outFile, 'w', newline='')
with open(inFile, 'r', newline='') as fr :
    with open(outFile, 'w', newline='') as fw :
        header = fr.readline().strip()
        header_list = header.split(',')
        # 작업 했음.
        header_str = ','.join(map(str,header_list))
        fw.writelines(header_str + '\n')
        for row in fr :
            row = row.strip()
            row_list = row.split(',')
            # 작업하기
            row_str = ','.join(map(str,row_list))
            fw.writelines(row_str + '\n')
print('Ok~')







# fr.close()
# fw.close()