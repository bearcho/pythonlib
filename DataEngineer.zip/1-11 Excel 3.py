# 엑셀 처리 2
from xlrd import open_workbook
from xlwt import Workbook
inFile = "data/EXCEL/sales_2013.xlsx"
outFile = "data/output/out04.xls"
workbook = open_workbook(inFile)
outWorkbook = Workbook() # 저장할 워크북
for  worksheet in  workbook.sheets() :
    sheetName = worksheet.name
    outWorksheet = outWorkbook.add_sheet(sheetName)
    writeRow = 0
    for  i  in  range(worksheet.nrows) :
        if i==0 or int(worksheet.cell_value(i, 0)) >= 4000 :
            for  k  in  range(worksheet.ncols) :
                value = worksheet.cell_value(i, k)
                outWorksheet.write(writeRow,k, value)
            writeRow += 1

outWorkbook.save(outFile)


