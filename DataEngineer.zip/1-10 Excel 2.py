# 엑셀 처리 2
from xlrd import open_workbook
from xlwt import Workbook

inFile = "data/EXCEL/sales_2013.xlsx"
outFile = "data/output/out01.xls"

outWorkbook = Workbook() # 저장할 워크북
outWorksheet = outWorkbook.add_sheet('2013_1')

with open_workbook(inFile) as workbook :
    worksheet = workbook.sheet_by_name('january_2013')
    for  i  in  range(worksheet.nrows) :
        for  k  in  range(worksheet.ncols) :
            value = worksheet.cell_value(i, k)
            outWorksheet.write(i,k, value)
    outWorkbook.save(outFile)