import pymysql

## 1. 커넥션 연결 및 커서 준비
conn = pymysql.connect(host='127.0.0.1', user='pyuser', password='1234', db='pydb', charset='utf8')
curr = conn.cursor()
## 2. SQL문 준비 및 실행
sql = "CREATE TABLE IF NOT EXISTS testTable(id INT, uname CHAR(8))"
curr.execute(sql)

sql = "INSERT INTO testTable(id, uname) VALUES(1000, '홍길동')"
curr.execute(sql)
sql = "INSERT INTO testTable(id, uname) VALUES(2000, '이순신')"
curr.execute(sql)
sql = "INSERT INTO testTable(id, uname) VALUES(3000, '김구')"
curr.execute(sql)
## 3. 커밋 (필요시)
conn.commit()

## 4. 커넥션 종료 및 커서 종료
curr.close()
conn.close()