# Yes24.com의 한국소설을 긁어오는 크롤러를 만들고 싶어요. (밥먹고나서)
#
import bs4
import requests
url = "http://www.yes24.com/24/Category/Display/001001046001"
html = requests.get(url)
bs_obj =  bs4.BeautifulSoup(html.content, "html.parser")

ul = bs_obj.find("ul", {"class":"clearfix"})
boxes = ul.findAll("div", {"class":"goods_name"}) # 각 상품 이름 리스트

for  box in boxes :
    ptag = box.findAll("a")
    print(ptag[0].text)

